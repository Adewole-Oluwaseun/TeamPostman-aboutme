import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.Alert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



public class code {

    //Import Selenium webdriver
    private WebDriver driver;



    @BeforeTest
    public void setup() throws InterruptedException {

        //locate where the chrome driver is
        System.setProperty("webdriver.chrome.driver", "Resources/Chrome driver/chromedriver-win64/chromedriver.exe");


        // Create ChromeOptions to configure browser preferences
        ChromeOptions act = new ChromeOptions();
        act.addArguments("--disable-notifications");

        //1. Pass the ChromeOptions to the ChromeDriver
        driver = new ChromeDriver(act);

        //2. Launch application URL (Konga URL (https://www.konga.com))

        driver.get("https://www.konga.com");
        Thread.sleep(2000);
        //Maximize your window
        driver.manage().window().maximize();
        Thread.sleep(1000);

    }

    @Test (priority = 0)
    public void start() throws InterruptedException {
        //declaring variable and it datatypes
        String title;
        String current_url;
        String pagesource;

        //3. get title of application page and save it in title variable
        title = driver.getTitle();
        //4. get currentURL of application  and save it in current_url variable
        current_url =  driver.getCurrentUrl();
        //4. get pagesource of application  page and save it in pagesource variable
        pagesource = driver.getPageSource();

        //Confirm URL of Application
        String expected_url = "https://www.konga.com/";

        if ( current_url.equals(expected_url))
        {
            System.out.println("URL Validation Test Passed: ");
        }
        else
        {
            System.out.println("URL Validation Test Failed");
        }
        //print out the confirmed url in the console
        System.out.println(current_url);

        //Confirm the Title on Dashboard of the homepage of application
        String expected_title ="Buy Phones, Fashion, Electronics in Nigeria_Konga Online Shopping | Konga Online Shopping";

        if ( title.equals(expected_title))
        {
            System.out.println("Title Validation Test Passed: ");
        }
        else
        {
            System.out.println( "Title Validation Test Failed");
        }
        Thread.sleep(7000);
        //print out the confirmed title in the console
        System.out.println(title);

        //Click on the signup/login button
        driver.findElement(By.xpath("//a[normalize-space()='Login / Signup']")).click();




    }


    @Test (priority = 1)
    public void LoginTest() throws InterruptedException {
        //Paste email into the email input element
        driver.findElement(By.xpath("//input[@id='username']")).sendKeys("okikiadewole2012@gmail.com");

        //Paste password into the password input element
        driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Dewole2012*");

        //Capture the login locator and click on login button element
        driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();

        Thread.sleep(2000);
    }

    @Test (priority = 2)
    public void LocatingLaptopTest() throws InterruptedException {

        //Click on computer and accessories Category
        driver.findElement(By.xpath("//*[@id=\'nav-bar-fix\']/div[2]/div/a[2]")).click();


        // Pause the current thread for 5000 milliseconds (5 seconds)
        Thread.sleep(5000);

        //Click on Laptop under computer and accessories as sub-categories
        driver.findElement(By.xpath("//*[@id=\"mainContent\"]/section[3]/section/div/section/div[2]/div[2]/ul/li[3]/a/label/span")).click();

        // Pause the current thread for 5000 milliseconds (5 seconds)
        Thread.sleep(7000);

        //Click on Apple Macbook
        driver.findElement(By.xpath("//span[normalize-space()='Apple MacBooks']")).click();
        // Pause the current thread for 5000 milliseconds (5 seconds)
        Thread.sleep(7000);


    }

    @Test (priority = 3)
    public void AddItemToCartTest() throws InterruptedException {

        //Click on Add to Cart
        driver.findElement(By.xpath("(//button[@type='submit'][normalize-space()='Add To Cart'])[1]")).click();
        // Pause the current thread for 5000 milliseconds (5 seconds)
        Thread.sleep(7000);


        // Click On My Cart
        driver.findElement(By.xpath("//span[normalize-space()='My Cart']")).click();

        // Click on check out
        driver.findElement(By.xpath("//button[normalize-space()='Checkout']")).click();
        Thread.sleep(20000);


    }


    @Test(priority = 4)
    public void selectAddress() throws InterruptedException {

        //6. change address
        driver.findElement(By.xpath("//*[@id=\"mainContent\"]/div/form/div/div[1]/section[1]/div/div/div[1]/div[2]/div/button")).click();
        Thread.sleep(5000);

        //6b. Add delivery Address to open the address book
        driver.findElement(By.xpath("//*[@id=\"mainContent\"]/div/form/div/div[1]/section[1]/div/div/div[2]/div[1]/div[2]/div[1]/div/button")).click();
        Thread.sleep(5000);

        //6c. select Address
        driver.findElement(By.xpath("//*[@id=\"app-content-wrapper\"]/div[2]/section/section/aside/div[2]/div/div/div[2]/div[2]/form/button")).click();
        Thread.sleep(3000);

        //6d. use Address
        driver.findElement(By.xpath("//*[@id=\"app-content-wrapper\"]/div[2]/section/section/aside/div[3]/div/div/div/a")).click();
        Thread.sleep(3000);
        System.out.println("select address");

    }
    @Test  (priority = 5)

    public  void paymentOptionTest() throws InterruptedException {

        // Payment Option
        driver.findElement(By.xpath("//input[@value='kpaygateway']")).click();
        Thread.sleep(7000);

        //click proceed to payment
        driver.findElement(By.xpath("//button[normalize-space()='Continue to Payment']")).click();
        Thread.sleep(16000);

    }


    @Test (priority = 6)
    public void selectcardmethod () throws InterruptedException {

        //9a change from default to iframe
        WebElement paymethod = driver.findElement(By.tagName("iframe"));

        driver.switchTo().frame("kpg-frame-component");
        Thread.sleep(10000);
        //9b select card payment method
        WebElement cardpayment = driver.findElement(By.className("Card"));
        cardpayment.click();

        Thread.sleep(5000);
    }

    @Test (priority = 7)
    public void carddetails() throws InterruptedException {

        //9. input card digits
        WebElement carddigit = driver.findElement(By.id("card-number"));carddigit.sendKeys("53652455667890");
        Thread.sleep(8000);

        //9b. input date
        driver.findElement(By.xpath("//*[@id=\"expiry\"]")).click();
        WebElement datedigit = driver.findElement(By.id("expiry"));datedigit.sendKeys("1225");
        Thread.sleep(8000);

        //9c. input CVV
        WebElement cvvdigit = driver.findElement(By.id("cvv"));cvvdigit.sendKeys("225");
        Thread.sleep(8000);
        System.out.println("input card details");

    }





    @Test (priority = 8)
    public void closeframe () throws InterruptedException {
        //12 close the Iframe that displays input card details
        WebElement exitframe = driver.findElement(By.className("data-card__close"));
        exitframe.click();
        System.out.println("exit iframe");
        Thread.sleep(6000);

    }
    @Test (priority = 9)
    public void exitIframe () throws InterruptedException {
        // Exit IFrame web
        driver.switchTo().defaultContent();
        Thread.sleep(5000);
        System.out.println("restore default");
    }

    @AfterTest
    public void closebrowser() {

        //Close all Active Browser or Shutdown driver
        driver.quit();
        System.out.println("Quit Browser Successfully");


    }
}











